<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'fudi' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '| 7>(o#D-7;bj:<ng3i;LC/4`&R5rA4l`rQn1S0!s][YaH.vXk(bvAW)klM-e|[5' );
define( 'SECURE_AUTH_KEY',  '8o QJ|%UJ=h}77_xu4M,TIqDY.VD_xZYCe&<FDRjRQ<k$-b3/:@$CW-X3[GHssgk' );
define( 'LOGGED_IN_KEY',    'XOjTH}DKXmotIx?+[*|%mYKx>Sop~|c`HW7bL<znQ@S9KS`2w7dkVcnk7>:(H@B<' );
define( 'NONCE_KEY',        '3xR%-cJ_1Wlz]}QVsW^@T(~Jf@9oli>$d+.|2z>[^QS:@M*;jX41vAe(6T-E/Y:>' );
define( 'AUTH_SALT',        'Pv{CGh6OU Y-R*eb8jQ;?6v^xzim$057g$m!o*RGj)x$@:LvJUHVhn]&9F#&gsQy' );
define( 'SECURE_AUTH_SALT', 'LW1R*3R;!*w&mgW)o.);y#Kse.?  :qBs!Wyu u?AkeTQZV.D[QW1;W1(S)6-Qg*' );
define( 'LOGGED_IN_SALT',   '8|B32ozt}:1P??BrPY0qpSi~(2E5 s=k.1+B>rCYkkU~MP{;<u3H0h.ye`Im|:Dm' );
define( 'NONCE_SALT',       'tnH2DQrB^ka2ceTw$v_D?S-=jnX)0Sipe.:]7sy+l=X)W)9BhaT+BYQNKP5hxBgr' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
